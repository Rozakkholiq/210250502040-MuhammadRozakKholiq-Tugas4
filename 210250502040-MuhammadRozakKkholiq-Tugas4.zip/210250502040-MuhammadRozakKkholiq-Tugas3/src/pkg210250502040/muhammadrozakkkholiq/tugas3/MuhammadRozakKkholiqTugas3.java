/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg210250502040.muhammadrozakkkholiq.tugas3;

/**
 *
 * @author HP
 */
public class MuhammadRozakKkholiqTugas3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int celcius = 35;
        if (celcius < 0){
            System.out.println("suhu sangat dingin");
        }else if (celcius < 20) {
            System.out.println("suhu dingin");
        }else if (celcius < 40) {
            System.out.println("suhu normal");
        }else {
            System.out.println("suhu panas");
    }
    }
    
}
